<div id="navigation">
	<div id="links">
		<img src="../images/star.png"><a href="index.php">Home</a>
		<img src="../images/star.png"><a href="">Link 1</a>
		<img src="../images/star.png"><a href="">Link 1</a>
		<img src="../images/star.png"><a href="">Link 1</a>
	</div>
</div>