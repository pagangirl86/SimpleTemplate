<div id="header">
	<!-- Replace src with banner path -->
	<img src="../images/banner.png">
</div>