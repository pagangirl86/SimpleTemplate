<div id="footer">
All content &copy; [year], [person]<br/><br/>
<!--Do not remove below-->
Template by <a href="http://laughingdragonstudio.zymichost.com">Laughing Dragon Studio</a>
</div>