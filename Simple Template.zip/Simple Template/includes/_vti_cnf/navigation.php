vti_encoding:SR|utf8-nl
vti_author:SR|Rowan\\Marie
vti_modifiedby:SR|Rowan\\Marie
vti_timelastmodified:TR|22 Nov 2013 03:38:43 -0000
vti_timecreated:TR|22 Nov 2013 03:30:55 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index.php
vti_nexttolasttimemodified:TW|22 Nov 2013 03:34:16 -0000
vti_cacheddtm:TX|22 Nov 2013 03:38:43 -0000
vti_filesize:IR|284
vti_cachedlinkinfo:VX|S|../images/star.png H|index.php S|../images/star.png S|../images/star.png S|../images/star.png
vti_cachedsvcrellinks:VX|FSUS|images/star.png NHUS|includes/index.php FSUS|images/star.png FSUS|images/star.png FSUS|images/star.png
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
