vti_encoding:SR|utf8-nl
vti_author:SR|Rowan\\Marie
vti_modifiedby:SR|Rowan\\Marie
vti_timelastmodified:TR|22 Nov 2013 03:52:55 -0000
vti_timecreated:TR|22 Nov 2013 03:43:53 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index.php
vti_nexttolasttimemodified:TW|22 Nov 2013 03:52:10 -0000
vti_cacheddtm:TX|22 Nov 2013 03:52:55 -0000
vti_filesize:IR|192
vti_cachedlinkinfo:VX|H|http://laughingdragonstudio.zymichost.com
vti_cachedsvcrellinks:VX|NHHS|http://laughingdragonstudio.zymichost.com
vti_cachedneedsrewrite:BR|false
vti_cachedhasbots:BR|false
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_charset:SR|utf-8
