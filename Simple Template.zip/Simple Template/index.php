﻿<!DOCTYPE html>
<html>

<head>
<meta content="en-us" http-equiv="Content-Language">
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<title>Simple Template</title>
<link href="simpletemplate.css" rel="stylesheet" type="text/css">
</head>

<body>
	<!--Wrapper contains all information -->
	<div id="wrapper">
		<!--Header contains banner-->
		<?php include('includes/header.php') ?>
		<?php include('includes/navigation.php') ?>
		<!--Change the last part for each page -->
		<?php include('includes/pagecontent/index.php')?>
		<!--Blurb at the bottom-->
		<?php include('includes/footer.php') ?>
	</div>
</body>

</html>
