vti_encoding:SR|utf8-nl
vti_author:SR|Rowan\\Marie
vti_modifiedby:SR|Rowan\\Marie
vti_timelastmodified:TR|22 Nov 2013 03:52:55 -0000
vti_timecreated:TR|22 Nov 2013 02:59:55 -0000
vti_title:SR|Simple Template
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|22 Nov 2013 03:43:45 -0000
vti_cacheddtm:TX|22 Nov 2013 03:43:45 -0000
vti_filesize:IR|667
vti_cachedtitle:SR|Simple Template
vti_cachedbodystyle:SR|<body>
vti_cachedlinkinfo:VX|Q|simpletemplate.css I|includes/header.php I|includes/navigation.php I|includes/pagecontent/index.php I|includes/footer.php
vti_cachedsvcrellinks:VX|FQUS|simpletemplate.css FIUS|includes/header.php FIUS|includes/navigation.php FIUS|includes/pagecontent/index.php FIUS|includes/footer.php
vti_cachedneedsrewrite:BR|true
vti_cachedhasbots:BR|true
vti_cachedhastheme:BR|false
vti_cachedhasborder:BR|false
vti_metatags:VR|HTTP-EQUIV=Content-Language en-us HTTP-EQUIV=Content-Type text/html;\\ charset=utf-8
vti_charset:SR|utf-8
vti_language:SR|en-us
